// Verzendscript voor de formulieren op een klantwebsite.
//
// Wordt vlak voor </body> in de pagina gezet: op het domein van de klant, en
// ook in de voorvertoning en achter een deellink, zodat je daar kunt zien wat
// een bezoeker krijgt. Niet in de editor: daar hoort op Verstuur drukken geen
// echte inzending op te leveren.
//
// Wat het doet:
//  1) Bij het laden het verborgen veld _ts op de huidige tijd zetten. De server
//     wijst af wie binnen twee seconden verstuurt, want dan is er niet getypt.
//  2) Het versturen overnemen van elke <form data-form-id>: de velden als JSON
//     naar /api/form-submit/{id}, en de uitkomst in het formulier tonen.
//     Zitten er bestanden bij, dan gaat het als multipart, met de velden als
//     JSON in _velden en de bestanden in _bestanden[]. Grote foto's worden
//     eerst verkleind: een foto van een telefoon is al snel 8 MB.
//  3) Het formulier kan op het domein van de klant staan en post naar ons, dus
//     het adres van de API komt uit een data-attribuut op dit script.
//  4) Na een geslaagde verzending maakt het formulier plaats voor de
//     bevestiging (data-form-dank), of gaat de bezoeker naar de pagina uit
//     data-form-redirect. Na herladen staat het formulier er gewoon weer.
//  5) Een formulier met een eigen id (data-form-id="contact-26fd2376", van een
//     aangeleverde site) heeft meestal zijn eigen script, dat naar /_forms/<id>
//     op het eigen domein post. Dat script gaat voor. Pas als niemand het
//     versturen tegenhield, posten wij zelf naar /_forms/<id>. Zonder dit
//     verstuurden allebei, en stond onze foutmelding naast hun bedankje.
//  6) Een formulier met een rekensom tegen spam (data-cms-captcha): de som
//     komt vers van /api/form-captcha/{id}, na een fout antwoord een nieuwe.

(function () {
    'use strict';

    // Alleen aan zetten als je een probleem zoekt. Standaard uit: dit script
    // draait op de website van een klant, en de payload bevat alles wat een
    // bezoeker heeft ingetypt. Dat hoort niet in de console van een vreemde te
    // belanden. Aan te zetten per bezoek met ?formdebug=1 in het adres.
    var DEBUG = false;
    try { DEBUG = DEBUG || window.location.search.indexOf('formdebug=1') !== -1; } catch (e) {}

    var LABEL = '[Formulier]';
    function log()  { if (DEBUG && window.console) console.log.apply(console, [LABEL].concat([].slice.call(arguments))); }
    function warn() { if (DEBUG && window.console) console.warn.apply(console, [LABEL].concat([].slice.call(arguments))); }

    var SCRIPT = document.currentScript;
    var API_BASE = (SCRIPT && SCRIPT.dataset && SCRIPT.dataset.apiBase) || window.location.origin;

    function init() {
        var tsVelden = document.querySelectorAll('input[name="_ts"]');
        for (var i = 0; i < tsVelden.length; i++) {
            if (!tsVelden[i].value) tsVelden[i].value = String(Date.now());
        }

        var forms = document.querySelectorAll('form[data-form-id]');
        log('formulieren gevonden:', forms.length);
        for (var j = 0; j < forms.length; j++) {
            if (isUuid(forms[j].getAttribute('data-form-id'))) {
                bindForm(forms[j]);
                nieuweSom(forms[j]);
            }
        }

        // Eén luisteraar op het document voor de formulieren met een eigen id.
        // Die hoort het submit-event pas nadat het script van de site het op het
        // formulier zelf heeft gehad, en ziet dus of dat het al overnam.
        document.addEventListener('submit', function (e) {
            var form = e.target;
            if (!form || form.tagName !== 'FORM' || !form.hasAttribute('data-form-id')) return;
            if (isUuid(form.getAttribute('data-form-id')) || e.defaultPrevented) return;
            e.preventDefault();
            if (geldig(form, false)) verstuur(form);
        });
    }

    /**
     * De rekensom tegen spam (data-cms-captcha). De server bedenkt hem en
     * rekent het antwoord na; hier komen de vraag en het token in het
     * formulier. Elke keer vers, ook na een fout antwoord.
     */
    function nieuweSom(form) {
        var vak = form.querySelector('[data-cms-captcha]');
        if (!vak) return;

        var vraag = vak.querySelector('[data-cms-captcha-vraag]');
        var antwoord = vak.querySelector('input[name="_captcha"]');
        var token = form.querySelector('input[name="_captcha_token"]');
        if (!token) {
            token = document.createElement('input');
            token.type = 'hidden';
            token.name = '_captcha_token';
            vak.appendChild(token);
        }
        if (antwoord) antwoord.value = '';

        fetch(API_BASE + '/api/form-captcha/' + encodeURIComponent(form.getAttribute('data-form-id')), { headers: { 'Accept': 'application/json' } })
            .then(function (res) { return res.ok ? res.json() : null; })
            .then(function (som) {
                if (!som || !som.vraag) return;
                if (vraag) vraag.textContent = 'Hoeveel is ' + som.vraag + '?';
                token.value = som.token || '';
            })
            .catch(function (e) { warn('geen som opgehaald', e); });
    }

    function isUuid(id) {
        return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id || '');
    }

    /**
     * Een site met een eigen script zet novalidate en toont zelf wat er
     * ontbreekt; de browser houdt dan niets tegen. Zonder deze controle
     * verstuurden we bij Prodaktief een leeg formulier, met "Bedankt" naast de
     * foutmeldingen en een leeg bericht bij de klant.
     */
    function geldig(form, alGestopt) {
        if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
            // Liet geen ander script de fouten zien, dan doet de browser het.
            if (!alGestopt && typeof form.reportValidity === 'function') form.reportValidity();
            return false;
        }
        return true;
    }

    function bindForm(form) {
        if (form.dataset._formBound === '1') return;
        form.dataset._formBound = '1';
        form.addEventListener('submit', function (e) {
            var alGestopt = e.defaultPrevented;
            e.preventDefault();

            if (geldig(form, alGestopt)) verstuur(form);
        });
    }

    /**
     * Waar de melding komt te staan. Heeft het formulier zelf geen plek
     * aangewezen, dan maken we er een boven de verstuurknop. Eerder viel het
     * terug op een alert, en dat is op de website van een klant geen gezicht;
     * erger nog, zonder alert-blokker zag een bezoeker soms niets en dacht hij
     * dat zijn bericht verstuurd was.
     */
    function statusVak(form) {
        var el = form.querySelector('[data-form-status]');

        if (!el) {
            el = document.createElement('div');
            el.setAttribute('data-form-status', '');
            el.style.cssText = 'display:none;margin:12px 0;padding:12px 14px;border-radius:10px;'
                + 'font-size:14px;line-height:1.5;border:1px solid transparent';

            var knop = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
            if (knop && knop.parentNode) knop.parentNode.insertBefore(el, knop);
            else form.appendChild(el);
        }

        if (!el.hasAttribute('role')) el.setAttribute('role', 'status');
        if (!el.hasAttribute('aria-live')) el.setAttribute('aria-live', 'polite');

        return el;
    }

    function toonStatus(el, bericht, soort) {
        if (!el) return;
        if (!bericht) { el.style.display = 'none'; el.textContent = ''; return; }

        el.textContent = bericht;
        // Het vak dat wij bij het neerzetten van een formulier meegeven heeft
        // de class hidden. Op een site met Tailwind betekent dat display:none,
        // en dan hielp het leegmaken van de inline stijl niets.
        el.classList.remove('hidden');
        el.hidden = false;
        el.style.display = 'block';
        // Eigen kleuren en niet via classes: wij weten niet welk stijlsysteem de
        // website van de klant gebruikt, dus een class als bg-green-50 doet het
        // daar misschien nergens.
        if (soort === 'ok') {
            el.style.background = '#ecfdf5'; el.style.borderColor = '#a7f3d0'; el.style.color = '#065f46';
        } else {
            el.style.background = '#fef2f2'; el.style.borderColor = '#fecaca'; el.style.color = '#991b1b';
        }
        // Om dezelfde reden: de classes voor de binnenruimte bestaan op de site
        // misschien niet, en dan plakt de tekst tegen de rand van het kleurvlak.
        try {
            if (parseFloat(window.getComputedStyle(el).paddingTop) === 0) {
                el.style.padding = '12px 14px';
                el.style.borderRadius = '10px';
                el.style.borderStyle = 'solid';
                el.style.borderWidth = '1px';
            }
        } catch (e) {}

        try { el.scrollIntoView({ behavior: 'smooth', block: soort === 'ok' ? 'center' : 'nearest' }); } catch (e) {}
    }

    /**
     * Na het versturen alleen nog de bevestiging. Het formulier-element zelf
     * blijft staan, want dat is vaak ook het kaartje met de achtergrond; alles
     * erin behalve de bevestiging gaat weg. Het staat alleen in de pagina van
     * dit moment: na herladen is het formulier er gewoon weer.
     */
    function alleenBevestiging(form, vak) {
        var ouder = form;
        while (ouder && ouder !== vak) {
            var verder = null;
            for (var i = 0; i < ouder.children.length; i++) {
                var kind = ouder.children[i];
                if (kind === vak || kind.contains(vak)) { verder = kind; continue; }
                kind.style.setProperty('display', 'none', 'important');
            }
            ouder = verder;
        }
    }

    /**
     * Het adres waar de bezoeker na het versturen heen gaat. Een pad als
     * /bedankt of een volledig adres; alles wat geen http(s) is, zoals
     * javascript:, laten we liggen. data-success is hoe een aangeleverde site
     * het noemt (Prodaktief): die bedankpagina hoort ook bij ons te werken.
     */
    function doorsturenNaar(form) {
        var doel = (form.getAttribute('data-form-redirect') || form.getAttribute('data-success') || '').trim();
        if (!doel) return '';
        try {
            var url = new URL(doel, window.location.href);
            return /^https?:$/.test(url.protocol) ? url.href : '';
        } catch (e) {
            return '';
        }
    }

    var MAX_MB = 10;

    /**
     * Maakt een grote foto kleiner voordat hij verstuurd wordt: hooguit 2000
     * pixels breed of hoog, als JPEG. Genoeg om op te zien wat er aan de hand
     * is, en het scheelt de bezoeker op een mobiele verbinding veel wachten.
     * Lukt het niet (een HEIC in een browser die dat niet kan lezen), dan gaat
     * het origineel.
     */
    function verklein(bestand) {
        return new Promise(function (klaar) {
            var origineel = { blob: bestand, naam: bestand.name || 'bestand' };
            if (!/^image\/(jpeg|png|webp)$/i.test(bestand.type) || bestand.size < 1024 * 1024 || !window.URL || !URL.createObjectURL) {
                klaar(origineel);
                return;
            }

            var adres = URL.createObjectURL(bestand);
            var img = new Image();
            img.onload = function () {
                var max = 2000;
                var schaal = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
                var doek = document.createElement('canvas');
                doek.width = Math.max(1, Math.round(img.naturalWidth * schaal));
                doek.height = Math.max(1, Math.round(img.naturalHeight * schaal));
                var ctx = doek.getContext('2d');
                // Een doorzichtige PNG wordt anders zwart als JPEG.
                ctx.fillStyle = '#fff';
                ctx.fillRect(0, 0, doek.width, doek.height);
                ctx.drawImage(img, 0, 0, doek.width, doek.height);
                URL.revokeObjectURL(adres);

                if (!doek.toBlob) { klaar(origineel); return; }
                doek.toBlob(function (blob) {
                    if (!blob || blob.size >= bestand.size) { klaar(origineel); return; }
                    klaar({ blob: blob, naam: origineel.naam.replace(/\.[^.]+$/, '') + '.jpg' });
                }, 'image/jpeg', 0.85);
            };
            img.onerror = function () { URL.revokeObjectURL(adres); klaar(origineel); };
            img.src = adres;
        });
    }

    /**
     * De velden als gewone JSON, of als multipart zodra er bestanden bij zitten.
     * Geeft een belofte met de body, of een melding voor de bezoeker.
     */
    function maakBody(form) {
        var fd = new FormData(form), velden = {}, bestanden = [];
        fd.forEach(function (waarde, sleutel) {
            if (typeof File !== 'undefined' && waarde instanceof File) {
                // Een bestandsveld waarin niets gekozen is, geeft een leeg bestand.
                if (waarde.size > 0 || waarde.name) bestanden.push({ veld: sleutel, bestand: waarde });
                return;
            }
            if (Object.prototype.hasOwnProperty.call(velden, sleutel)) {
                if (!Array.isArray(velden[sleutel])) velden[sleutel] = [velden[sleutel]];
                velden[sleutel].push(waarde);
            } else {
                velden[sleutel] = waarde;
            }
        });

        if (!bestanden.length) {
            return Promise.resolve({ json: true, body: JSON.stringify(velden) });
        }

        return Promise.all(bestanden.map(function (b) { return verklein(b.bestand); })).then(function (klaar) {
            for (var i = 0; i < klaar.length; i++) {
                if (klaar[i].blob.size > MAX_MB * 1024 * 1024) {
                    return { fout: 'Het bestand "' + klaar[i].naam + '" is te groot. Een bestand mag maximaal ' + MAX_MB + ' MB zijn.' };
                }
            }

            var body = new FormData();
            body.append('_velden', JSON.stringify(velden));
            body.append('_bestandvelden', JSON.stringify(bestanden.map(function (b) { return b.veld; })));
            for (var j = 0; j < klaar.length; j++) body.append('_bestanden[]', klaar[j].blob, klaar[j].naam);

            return { json: false, body: body };
        });
    }

    function knopBezig(knop, bezig) {
        if (!knop) return;
        knop.disabled = bezig;
        if (bezig) {
            knop.dataset._label = knop.tagName === 'BUTTON' ? (knop.textContent || '') : (knop.value || '');
            if (knop.tagName === 'BUTTON') knop.textContent = 'Versturen…'; else knop.value = 'Versturen…';
        } else {
            var terug = knop.dataset._label || 'Verstuur';
            if (knop.tagName === 'BUTTON') knop.textContent = terug; else knop.value = terug;
        }
    }

    function verstuur(form) {
        var formId = form.getAttribute('data-form-id');
        if (!formId) return;

        var vak = statusVak(form);
        var knop = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');

        toonStatus(vak, '', '');
        knopBezig(knop, true);

        maakBody(form).then(function (verzending) {
            if (verzending.fout) {
                toonStatus(vak, verzending.fout, 'fout');
                return;
            }

            // Bij multipart geen Content-Type zetten: de browser vult hem zelf
            // in, met de grens tussen de delen erbij.
            var koppen = { 'Accept': 'application/json' };
            if (verzending.json) koppen['Content-Type'] = 'application/json';

            var adres = isUuid(formId)
                ? API_BASE + '/api/form-submit/' + encodeURIComponent(formId)
                : window.location.origin + '/_forms/' + encodeURIComponent(formId);

            return fetch(adres, {
                method: 'POST',
                headers: koppen,
                body: verzending.body
            }).then(function (res) {
                return res.json().catch(function () { return {}; }).then(function (data) {
                    return { ok: res.ok, status: res.status, data: data };
                });
            }).then(function (r) {
                if (r.ok) {
                    // Een eigen bedanktekst uit de editor gaat voor op de standaard
                    // melding van de server.
                    var eigen = (form.getAttribute('data-form-dank') || '').trim();
                    toonStatus(vak, eigen || r.data.message || 'Bedankt voor je bericht!', 'ok');

                    // Voor de conversiemeting: Tag Manager hoort een inzending pas
                    // te tellen als hij echt binnen is. Het submit-event zelf
                    // zegt dat niet, want dat breken we hierboven af.
                    try {
                        window.dataLayer = window.dataLayer || [];
                        window.dataLayer.push({ event: 'formulier_verzonden', formulier: formId });
                    } catch (e) {}
                    alleenBevestiging(form, vak);
                    form.reset();
                    var ts = form.querySelector('input[name="_ts"]');
                    if (ts) ts.value = String(Date.now());
                    nieuweSom(form);

                    var doel = doorsturenNaar(form);
                    if (doel) window.location.assign(doel);
                    return;
                }

                // 429 komt van de begrenzing per IP-adres. Dat is iets anders dan
                // een storing, en daar hoort de bezoeker ook iets anders te lezen.
                // 413 is een verzending die de server te groot vond.
                var melding = r.status === 429
                    ? 'Je hebt net al een bericht gestuurd. Probeer het over een paar minuten nog eens.'
                    : r.status === 413
                        ? 'De bestanden zijn samen te groot. Stuur er minder of kleinere mee.'
                        : (r.data.error || 'Er ging iets mis bij het versturen. Probeer het zo nog eens.');

                warn('versturen mislukt, status', r.status);
                toonStatus(vak, melding, 'fout');
                if (r.data && r.data.captcha) nieuweSom(form);
            });
        }).catch(function (e) {
            warn('geen verbinding', e);
            toonStatus(vak, 'Geen verbinding met de server. Controleer je internet en probeer het opnieuw.', 'fout');
        }).then(function () {
            knopBezig(knop, false);
        });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
